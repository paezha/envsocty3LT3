library(testthat)
library(envsocty3LT3)

test_check("envsocty3LT3")
